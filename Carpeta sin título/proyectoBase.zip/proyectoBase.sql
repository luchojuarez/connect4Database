CREATE DATABASE  IF NOT EXISTS `proyectoBase` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `proyectoBase`;
-- MySQL dump 10.13  Distrib 5.5.31, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: proyectoBase
-- ------------------------------------------------------
-- Server version	5.5.31-0ubuntu0.12.10.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `casa`
--

DROP TABLE IF EXISTS `casa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `casa` (
  `codigo` int(11) NOT NULL DEFAULT '0',
  `categoria` varchar(50) DEFAULT NULL,
  `cant_habitaciones` int(11) DEFAULT NULL,
  PRIMARY KEY (`codigo`),
  CONSTRAINT `fk_inmuebleCasa` FOREIGN KEY (`codigo`) REFERENCES `inmueble` (`codigo`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `casa`
--

LOCK TABLES `casa` WRITE;
/*!40000 ALTER TABLE `casa` DISABLE KEYS */;
INSERT INTO `casa` VALUES (1,'B',0),(5,'A',0);
/*!40000 ALTER TABLE `casa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inmueble`
--

DROP TABLE IF EXISTS `inmueble`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inmueble` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `mts2` float DEFAULT NULL,
  `direccion` varchar(50) NOT NULL,
  PRIMARY KEY (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inmueble`
--

LOCK TABLES `inmueble` WRITE;
/*!40000 ALTER TABLE `inmueble` DISABLE KEYS */;
INSERT INTO `inmueble` VALUES (1,260,'Sarmiento 342'),(2,500,'Olguin 1280'),(3,1202,'Alvear 1052'),(4,200,'Alvear 1052'),(5,1234,'Sobremonte 503'),(6,421,'Peron 530'),(7,30,'San Martin 21');
/*!40000 ALTER TABLE `inmueble` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `respuesta`
--

DROP TABLE IF EXISTS `respuesta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `respuesta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_consulta` int(11) DEFAULT NULL,
  `dni` int(11) DEFAULT NULL,
  `texto` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_usuarioRespuesta` (`dni`),
  KEY `fk_consulta` (`codigo_consulta`),
  CONSTRAINT `fk_usuarioRespuesta` FOREIGN KEY (`dni`) REFERENCES `usuario` (`dni`) ON DELETE CASCADE,
  CONSTRAINT `fk_consulta` FOREIGN KEY (`codigo_consulta`) REFERENCES `consulta` (`codigo_consulta`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `respuesta`
--

LOCK TABLES `respuesta` WRITE;
/*!40000 ALTER TABLE `respuesta` DISABLE KEYS */;
INSERT INTO `respuesta` VALUES (1,1,291,'Esta excelente, cuando quieras lo visitamos'),(2,2,293,'El dia martes podria ser. Llamame cualquier cosa'),(3,2,293,'El dia martes podria ser. Llamame cualquier cosa'),(4,2,293,'El dia martes podria ser. Llamame cualquier cosa'),(5,2,293,'El dia martes podria ser. Llamame cualquier cosa'),(6,2,293,'El dia martes podria ser. Llamame cualquier cosa'),(7,2,293,'El dia martes podria ser. Llamame cualquier cosa'),(8,2,293,'El dia martes podria ser. Llamame cualquier cosa'),(9,2,293,'El dia martes podria ser. Llamame cualquier cosa'),(10,4,290,'El dia martes podria ser. Llamame cualquier cosa'),(11,2,293,'El dia martes podria ser. Llamame cualquier cosa'),(12,2,293,'El dia martes podria ser. Llamame cualquier cosa');
/*!40000 ALTER TABLE `respuesta` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER consultas_menos_10_respuestas
BEFORE INSERT ON respuesta 
for each row 
BEGIN
        DECLARE contador INT;
        SELECT COUNT(codigo_consulta) FROM respuesta WHERE codigo_consulta=new.codigo_consulta INTO contador;
        IF contador>=10 THEN      
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Excede el limite de respuesta posible por una consulta.';
        END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `auditoria_anuncio`
--

DROP TABLE IF EXISTS `auditoria_anuncio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auditoria_anuncio` (
  `codigo` int(11) NOT NULL,
  `fecha_final` date NOT NULL,
  `fecha_inicio` date NOT NULL,
  `dni` int(11) NOT NULL,
  `monto_v` double unsigned DEFAULT NULL,
  `monto_a` double unsigned DEFAULT NULL,
  `fecha_eliminacion` date DEFAULT NULL,
  `usuario_elimino` varchar(50) DEFAULT NULL,
  UNIQUE KEY `dni` (`dni`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditoria_anuncio`
--

LOCK TABLES `auditoria_anuncio` WRITE;
/*!40000 ALTER TABLE `auditoria_anuncio` DISABLE KEYS */;
INSERT INTO `auditoria_anuncio` VALUES (6,'2015-05-01','2013-05-24',300,1242.21,3,'2013-05-24','root@localhost');
/*!40000 ALTER TABLE `auditoria_anuncio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cochera`
--

DROP TABLE IF EXISTS `cochera`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cochera` (
  `codigo` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`codigo`),
  CONSTRAINT `fk_inmuebleCochera` FOREIGN KEY (`codigo`) REFERENCES `inmueble` (`codigo`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cochera`
--

LOCK TABLES `cochera` WRITE;
/*!40000 ALTER TABLE `cochera` DISABLE KEYS */;
INSERT INTO `cochera` VALUES (7);
/*!40000 ALTER TABLE `cochera` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `anuncio`
--

DROP TABLE IF EXISTS `anuncio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `anuncio` (
  `codigo` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_inmueble` int(11) NOT NULL,
  `fecha_inicio` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_final` date NOT NULL,
  `dni` int(11) DEFAULT NULL,
  `monto_v` double unsigned DEFAULT NULL,
  `monto_a` double unsigned DEFAULT NULL,
  PRIMARY KEY (`codigo`),
  KEY `fk_usuario` (`dni`),
  KEY `fk_inmueble` (`codigo_inmueble`),
  CONSTRAINT `fk_usuario` FOREIGN KEY (`dni`) REFERENCES `usuario` (`dni`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_inmueble` FOREIGN KEY (`codigo_inmueble`) REFERENCES `inmueble` (`codigo`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `anuncio`
--

LOCK TABLES `anuncio` WRITE;
/*!40000 ALTER TABLE `anuncio` DISABLE KEYS */;
INSERT INTO `anuncio` VALUES (1,1,'2013-05-24 12:38:37','2013-12-06',290,NULL,10000),(2,2,'2013-05-24 12:38:37','2014-06-01',291,10000.21,1.213),(3,3,'2013-05-24 12:38:37','2013-08-23',292,121421,1.5),(4,4,'2013-05-24 12:38:38','2013-11-24',293,121411,1),(5,5,'2013-05-24 12:38:38','2014-01-01',290,412442.21,1.731),(7,7,'2013-05-24 12:38:38','2016-12-12',304,1235511.21,2.5);
/*!40000 ALTER TABLE `anuncio` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER controlar_fecha
BEFORE INSERT ON anuncio 
for each row 
BEGIN
        if  new.fecha_inicio > new.fecha_final then
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Fecha Final es anterior a la Fecha Inicial';
        END IF;
            IF EXISTS(SELECT * FROM anuncio WHERE codigo_inmueble=new.codigo_inmueble and  new.fecha_inicio<=fecha_final) THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Se solapan las fecha del inmueble.';
        END IF;
            IF  new.monto_a IS NULL  AND new.monto_v IS NULL THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Ingrese el monto de alquiler o el monto de venta.';
        END IF; 
        
 END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER almacenar_publicacion_eliminar
AFTER DELETE ON anuncio 
for each row 
BEGIN
    INSERT INTO auditoria_anuncio VALUES (old.codigo,old.fecha_final,old.fecha_inicio, old.dni, old.monto_v, old.monto_a, CURDATE(), CURRENT_USER());
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `depto`
--

DROP TABLE IF EXISTS `depto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `depto` (
  `codigo` int(11) NOT NULL DEFAULT '0',
  `expensas` double unsigned DEFAULT NULL,
  PRIMARY KEY (`codigo`),
  CONSTRAINT `fk_inmuebleDepto` FOREIGN KEY (`codigo`) REFERENCES `inmueble` (`codigo`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `depto`
--

LOCK TABLES `depto` WRITE;
/*!40000 ALTER TABLE `depto` DISABLE KEYS */;
INSERT INTO `depto` VALUES (2,241),(3,400),(6,NULL);
/*!40000 ALTER TABLE `depto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `dni` int(11) NOT NULL,
  `nombre_apellido` varchar(50) NOT NULL,
  `nom_usuario` varchar(50) NOT NULL,
  `contraseña` varchar(50) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  PRIMARY KEY (`dni`),
  UNIQUE KEY `dni` (`dni`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (290,'Mariano Politano','mpoli','cacho','0311'),(291,'Fernando Raverta','fravert','nando','0312'),(292,'Cesar Cornejo','ccornejo','corne','0313'),(293,'Ana Garcia','ana.garcia','ana','0314'),(300,'Julio Lopez','jlopez','julio','0315'),(304,'Juan Perez','jperez','juan','0316');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consulta`
--

DROP TABLE IF EXISTS `consulta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta` (
  `codigo_consulta` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_anuncio` int(11) NOT NULL,
  `texto` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`codigo_consulta`),
  KEY `fk_anuncio` (`codigo_anuncio`),
  CONSTRAINT `fk_anuncio` FOREIGN KEY (`codigo_anuncio`) REFERENCES `anuncio` (`codigo`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consulta`
--

LOCK TABLES `consulta` WRITE;
/*!40000 ALTER TABLE `consulta` DISABLE KEYS */;
INSERT INTO `consulta` VALUES (1,1,'Excelente. ¿Como es la financiacion?'),(2,2,'Queria saber cual es la condicion que se encuentra este inmueble.'),(3,5,'Muy lindo!! Cuando se podria visitarlo? .'),(4,7,'MUY CAROOO');
/*!40000 ALTER TABLE `consulta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `local`
--

DROP TABLE IF EXISTS `local`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `local` (
  `codigo` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`codigo`),
  CONSTRAINT `fk_inmuebleLocal` FOREIGN KEY (`codigo`) REFERENCES `inmueble` (`codigo`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `local`
--

LOCK TABLES `local` WRITE;
/*!40000 ALTER TABLE `local` DISABLE KEYS */;
INSERT INTO `local` VALUES (4);
/*!40000 ALTER TABLE `local` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-05-24  9:48:32
