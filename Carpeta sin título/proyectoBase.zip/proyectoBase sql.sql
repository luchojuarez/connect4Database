/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;

DROP TABLE IF EXISTS usuario;
CREATE TABLE usuario(
 dni INTEGER UNIQUE NOT NULL,
 nombre_apellido VARCHAR(50) NOT NULL,
 nom_usuario VARCHAR(50) NOT NULL,
 contraseña VARCHAR(50) NOT NULL,
 telefono VARCHAR(20) NOT NULL, 
CONSTRAINT pk_usuario PRIMARY KEY (dni));

DROP TABLE IF EXISTS inmueble;
CREATE TABLE inmueble(
 codigo INTEGER NOT NULL AUTO_INCREMENT,
 mts2 float,
 direccion VARCHAR(50) NOT NULL,
CONSTRAINT pk_inmueble PRIMARY KEY (codigo));

DROP TABLE IF EXISTS anuncio;
CREATE TABLE anuncio(
 codigo INTEGER AUTO_INCREMENT,
 codigo_inmueble INTEGER NOT NULL,
 fecha_inicio TIMESTAMP DEFAULT NOW(),
 fecha_final DATE NOT NULL,
 dni INTEGER,
 monto_v REAL UNSIGNED,
 monto_a REAL UNSIGNED, 
CONSTRAINT fk_usuario FOREIGN KEY (dni) REFERENCES  usuario(dni) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT fk_inmueble FOREIGN KEY (codigo_inmueble) REFERENCES inmueble(codigo) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT pk_anuncio PRIMARY KEY (codigo));

DROP TABLE IF EXISTS consulta;
CREATE TABLE consulta(
 codigo_consulta INTEGER AUTO_INCREMENT,
 codigo_anuncio INTEGER NOT NULL,
 texto VARCHAR(200),
CONSTRAINT fk_anuncio FOREIGN KEY (codigo_anuncio) REFERENCES anuncio (codigo) ON DELETE CASCADE,
CONSTRAINT pk_consulta PRIMARY KEY (codigo_consulta));

DROP TABLE IF EXISTS respuesta;
CREATE TABLE respuesta(
 id INTEGER AUTO_INCREMENT,
 codigo_consulta INTEGER,
 dni INTEGER,
 texto VARCHAR(200),
CONSTRAINT fk_usuarioRespuesta FOREIGN KEY (dni) REFERENCES usuario (dni) ON DELETE CASCADE,
CONSTRAINT fk_consulta FOREIGN KEY (codigo_consulta) REFERENCES consulta (codigo_consulta) ON DELETE CASCADE,
CONSTRAINT pk_respuesta PRIMARY KEY (id));

DROP TABLE IF EXISTS casa;
CREATE TABLE casa(
 codigo INTEGER,
 categoria VARCHAR(50),
 cant_habitaciones INTEGER,
CONSTRAINT fk_inmuebleCasa FOREIGN KEY (codigo) REFERENCES inmueble (codigo) ON DELETE CASCADE,
CONSTRAINT pk_casa PRIMARY KEY (codigo));

DROP TABLE IF EXISTS local;
CREATE TABLE local(
 codigo INTEGER,
CONSTRAINT fk_inmuebleLocal FOREIGN KEY (codigo) REFERENCES inmueble (codigo)ON DELETE CASCADE,
CONSTRAINT pk_local PRIMARY KEY (codigo));

DROP TABLE IF EXISTS cochera;
CREATE TABLE cochera(
 codigo INTEGER,
CONSTRAINT fk_inmuebleCochera FOREIGN KEY (codigo) REFERENCES inmueble (codigo)ON DELETE CASCADE,
CONSTRAINT pk_cochera PRIMARY KEY (codigo));

DROP TABLE IF EXISTS depto;
CREATE TABLE depto(
 codigo INTEGER,
 expensas REAL UNSIGNED,
CONSTRAINT fk_inmuebleDepto FOREIGN KEY (codigo) REFERENCES inmueble (codigo)ON DELETE CASCADE,
CONSTRAINT pk_depto PRIMARY KEY (codigo));

DROP TABLE IF EXISTS auditoria_anuncio;
CREATE TABLE auditoria_anuncio(
 codigo INTEGER NOT NULL,
 fecha_final DATE NOT NULL,
 fecha_inicio DATE NOT NULL,
 dni INTEGER UNIQUE NOT NULL,
 monto_v REAL UNSIGNED,
 monto_a REAL UNSIGNED, 
 fecha_eliminacion DATE,
 usuario_elimino VARCHAR(50)
);

delimiter $$ 
CREATE TRIGGER almacenar_publicacion_eliminar
AFTER DELETE ON anuncio 
for each row 
BEGIN
    INSERT INTO auditoria_anuncio VALUES (old.codigo,old.fecha_final,old.fecha_inicio, old.dni, old.monto_v, old.monto_a, CURDATE(), CURRENT_USER());
END;
$$

delimiter $$ 
CREATE TRIGGER consultas_menos_10_respuestas
BEFORE INSERT ON respuesta 
for each row 
BEGIN
        DECLARE contador INT;
        SELECT COUNT(codigo_consulta) FROM respuesta WHERE codigo_consulta=new.codigo_consulta INTO contador;
        IF contador>=10 THEN      
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Excede el limite de respuesta posible por una consulta.';
        END IF;
END;
$$

delimiter $$ 
CREATE TRIGGER controlar_fecha
BEFORE INSERT ON anuncio 
for each row 
BEGIN
        if  new.fecha_inicio > new.fecha_final then
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Fecha Final es anterior a la Fecha Inicial';
        END IF;
            IF EXISTS(SELECT * FROM anuncio WHERE codigo_inmueble=new.codigo_inmueble and  new.fecha_inicio<=fecha_final) THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Se solapan las fecha del inmueble.';
        END IF;
            IF  new.monto_a IS NULL  AND new.monto_v IS NULL THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Ingrese el monto de alquiler o el monto de venta.';
        END IF; 
        
 END;
$$

/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;